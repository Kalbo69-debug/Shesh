package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class Bball_Reserve_Page extends AppCompatActivity {

    EditText lastname, firstname, contactnum, email;

    Button payment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bball_reserve_page);

        lastname = findViewById(R.id.editlastname);
        firstname = findViewById(R.id.editfirstname);
        contactnum = findViewById(R.id.editcontactnum);
        email = findViewById(R.id.editemail);
        payment = findViewById(R.id.payment);
        Spinner court = findViewById(R.id.courtspinner);


        court.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String court = parent.getItemAtPosition(position).toString();
                    Toast.makeText(Bball_Reserve_Page.this, "Selected Court: " + court, Toast.LENGTH_LONG).show();
                }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Playground at Ronac Art Center");
        arrayList.add("Philippine Army Gym");
        arrayList.add("Treston International College Basketball Court");
        arrayList.add("Kings of the Court");
        arrayList.add("West Greenhills Basketball Court");
        arrayList.add("Guadalupe Nuevo Barangay Hall and Sports Complex");
        arrayList.add("Greenmeadows Clubhouse Indoor Basketball Court");
        arrayList.add("San Juan Gym");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arrayList);
        adapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        court.setAdapter(adapter);




        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String lname = lastname.getText().toString();
                String fname = firstname.getText().toString();
                String Email = email.getText().toString();
                String contact = contactnum.getText().toString();


                if (TextUtils.isEmpty(lname) || TextUtils.isEmpty(fname) || TextUtils.isEmpty(contact) || TextUtils.isEmpty(Email))  {
                    Toast.makeText(Bball_Reserve_Page.this, "All Fields are required", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(getApplicationContext(), Dashboard.class);
                    startActivity(intent);
                }

            }
        });





    }
}