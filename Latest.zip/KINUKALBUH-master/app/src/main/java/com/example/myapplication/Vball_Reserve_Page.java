package com.example.myapplication;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Vball_Reserve_Page extends AppCompatActivity {

    EditText lastname, firstname, contactnum, email;

    Button payment, btndate, btntime;

    private TextView txtdate, txttime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vball_reserve_page);

        txtdate = findViewById(R.id.txtDate);
        txttime = findViewById(R.id.txtTime);
        btndate = findViewById(R.id.btnDate);
        btntime = findViewById(R.id.btnTime);

        lastname = findViewById(R.id.editlastname);
        firstname = findViewById(R.id.editfirstname);
        contactnum = findViewById(R.id.editcontactnum);
        email = findViewById(R.id.editemail);
        payment = findViewById(R.id.payment);

        Spinner court = findViewById(R.id.courtspinner);

        btndate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openDate();//dates
            }
        });

        btntime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openTime(); //time
            }
        });


        court.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String court = parent.getItemAtPosition(position).toString();
                Toast.makeText(Vball_Reserve_Page.this, "Selected Court: " + court, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Amoranto Sports Complex");
        arrayList.add("Village Sports Club");
        arrayList.add("Sands at SM by the Bay");
        arrayList.add("Cantada Sports Center");
        arrayList.add("Lourdes School of Mandaluyong");
        arrayList.add("G court");
        arrayList.add("Ateneo College Covered Courts");
        arrayList.add("Quezon City Sports Club");



        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arrayList);
        adapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        court.setAdapter(adapter);

        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String lname = lastname.getText().toString();
                String fname = firstname.getText().toString();
                String Email = email.getText().toString();
                String contact = contactnum.getText().toString();

                if (TextUtils.isEmpty(lname) || TextUtils.isEmpty(fname) || TextUtils.isEmpty(contact) || TextUtils.isEmpty(Email)) {
                    Toast.makeText(Vball_Reserve_Page.this, "All Fields are required", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(getApplicationContext(), Payment_Page.class);
                    startActivity(intent); // Will open payment page
                }


            }
        });
    }

    private void openDate() {
        DatePickerDialog date = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                txtdate.setText(String.valueOf(year) + "." + String.valueOf(month) + "." + String.valueOf(dayOfMonth));
            }
        }, 2024, 0, 10);
        {
            date.show();
        }
    }

    private void openTime() {
        TimePickerDialog time = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                txttime.setText(String.valueOf(hourOfDay) + "." + String.valueOf(minute));

            }
        }, 15, 00, true);
        {
            time.show();
        }
    }
}
