package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import java.util.ArrayList;

public class Bball_Reserve_Page extends AppCompatActivity {

    EditText lastname, firstname, contactnum, email;
    Button payment, btndate, btntime;
    TextView txtdate, txttime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bball_reserve_page);

        txtdate = findViewById(R.id.txtDate);
        txttime = findViewById(R.id.txtTime);
        btndate = findViewById(R.id.btnDate);
        btntime = findViewById(R.id.btnTime);

        lastname = findViewById(R.id.editlastname);
        firstname = findViewById(R.id.editfirstname);
        contactnum = findViewById(R.id.editcontactnum);
        email = findViewById(R.id.editemail);
        payment = findViewById(R.id.payment);

        Spinner court = findViewById(R.id.courtspinner);

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Playground at Ronac Art Center");
        arrayList.add("Philippine Army Gym");
        arrayList.add("Treston International College Basketball Court");
        arrayList.add("Kings of the Court");
        arrayList.add("West Greenhills Basketball Court");
        arrayList.add("Guadalupe Nuevo Barangay Hall and Sports Complex");
        arrayList.add("Greenmeadows Clubhouse Indoor Basketball Court");
        arrayList.add("San Juan Gym");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        court.setAdapter(adapter);

        btndate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDate();
            }
        });

        btntime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTime();
            }
        });

        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateFields()) {
                    Intent intent = new Intent(getApplicationContext(), Payment_Page.class);
                    intent.putExtra("lastname", lastname.getText().toString());
                    intent.putExtra("firstname", firstname.getText().toString());
                    intent.putExtra("contactnumber", contactnum.getText().toString());
                    intent.putExtra("email", email.getText().toString());
                    intent.putExtra("courts", court.getSelectedItem().toString());
                    intent.putExtra("date", txtdate.getText().toString());
                    intent.putExtra("time", txttime.getText().toString());
                    startActivity(intent);
                }
            }
        });
    }

    private void openDate() {
        DatePickerDialog date = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                txtdate.setText(year + "-" + (month + 1) + "-" + dayOfMonth);
            }
        }, 2024, 0, 10);
        date.show();
    }

    private void openTime() {
        TimePickerDialog time = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @SuppressLint("DefaultLocale")
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                txttime.setText(String.format("%02d:%02d", hourOfDay, minute));
            }
        }, 15, 0, true);
        time.show();
    }

    private boolean validateFields() {
        String lname = lastname.getText().toString().trim();
        String fname = firstname.getText().toString().trim();
        String contact = contactnum.getText().toString().trim();
        String Email = email.getText().toString().trim();
        String date = txtdate.getText().toString().trim();
        String time = txttime.getText().toString().trim();

        if (TextUtils.isEmpty(lname) || TextUtils.isEmpty(fname) || TextUtils.isEmpty(contact) || TextUtils.isEmpty(Email) || TextUtils.isEmpty(date) || TextUtils.isEmpty(time)) {
            Toast.makeText(Bball_Reserve_Page.this, "All Fields are required", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!TextUtils.isDigitsOnly(contact)) {
            Toast.makeText(Bball_Reserve_Page.this, "Contact Number must be numeric", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}