package com.example.myapplication;

public class Payment {

    private String paymentId;
    private String amount;

    // Default constructor required for calls to DataSnapshot.getValue(Payment.class)
    public Payment() {
    }

    public Payment(String paymentId, String amount) {
        this.paymentId = paymentId;
        this.amount = amount;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
