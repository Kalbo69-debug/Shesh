package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class Dashboard extends AppCompatActivity {

    ImageButton basketball, volleyball, details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize ImageButtons
        basketball = findViewById(R.id.btnBasketball);
        volleyball = findViewById(R.id.btnVolleyball);
        details = findViewById(R.id.btnDetails);

        // Set onClick listeners for each button
        basketball.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start Ball_Reserve_Page activity
                Intent intent = new Intent(Dashboard.this, Bball_Reserve_Page.class);
                startActivity(intent);
            }
        });

        volleyball.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start Vball_Reserve_Page activity
                Intent intent = new Intent(Dashboard.this, Vball_Reserve_Page.class);
                startActivity(intent);
            }
        });

        details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, Reservation_Details.class);
                startActivity(intent);
            }
        });
    }
}