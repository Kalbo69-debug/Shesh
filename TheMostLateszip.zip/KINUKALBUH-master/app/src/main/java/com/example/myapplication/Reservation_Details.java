package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Reservation_Details extends AppCompatActivity {

    private String reservationStatus;
    Button btnConfirm, btnCancel;
    private View confirmButton, cancelButton;

    private TextView txtLastname, txtFirstname, txtContactnum, txtEmail, txtCourts, txtDate, txtTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reservation_details);

        confirmButton = findViewById(R.id.btnConfirm);
        cancelButton = findViewById(R.id.btnCancel);

        txtLastname = findViewById(R.id.txtLastname);
        txtFirstname = findViewById(R.id.txtFirstname);
        txtContactnum = findViewById(R.id.txtContactnum);
        txtEmail = findViewById(R.id.txtEmail);
        txtCourts = findViewById(R.id.txtCourts);
        txtDate = findViewById(R.id.txtDate);
        txtTime = findViewById(R.id.txtTime);


        Intent intent = getIntent();
        txtLastname.setText(intent.getStringExtra("lastname"));
        txtFirstname.setText(intent.getStringExtra("firstname"));
        txtContactnum.setText(intent.getStringExtra("contactnumber"));
        txtEmail.setText(intent.getStringExtra("email"));
        txtCourts.setText(intent.getStringExtra("courts"));
        txtDate.setText(intent.getStringExtra("date"));
        txtTime.setText(intent.getStringExtra("time"));

        
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update status to "Confirmed" when the button is clicked
                reservationStatus = "Confirmed";
                // Update UI to reflect the new status
                updateStatusUI();
            }
        });
        reservationStatus = "Pending";
        // Update UI to reflect the initial status
        updateStatusUI();

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelReservation();
            }
        });
    }
    private void updateStatusUI() {
        // Example: Update a TextView to display the current status
        TextView statusTextView = findViewById(R.id.txtStatus);
        statusTextView.setText("Status: " + reservationStatus);
    }
    private void cancelReservation() {
        // Implement logic to cancel the reservation here
        // For example, you might want to remove the reservation from the database or reset the reservation details.

        // After canceling the reservation, you can navigate back to the previous activity or perform any other necessary action.
        finish(); // Finish the current activity and return to the previous activity
    }
}
