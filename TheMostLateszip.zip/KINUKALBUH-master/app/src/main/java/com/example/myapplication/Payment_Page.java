package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Payment_Page extends AppCompatActivity {

    private TextView lastname, firstname, contactnumber, email, courts, date, time;
    private Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_page);

        lastname = findViewById(R.id.txtLastname);
        firstname = findViewById(R.id.txtFirstname);
        contactnumber = findViewById(R.id.txtContactnum);
        email = findViewById(R.id.txtEmail);
        courts = findViewById(R.id.txtCourts);
        date = findViewById(R.id.txtDate);
        time = findViewById(R.id.txtTime);
        submit = findViewById(R.id.btnSubmit);


        Intent intent = getIntent();
        lastname.setText(intent.getStringExtra("lastname"));
        firstname.setText(intent.getStringExtra("firstname"));
        contactnumber.setText(intent.getStringExtra("contactnumber"));
        email.setText(intent.getStringExtra("email"));
        courts.setText(intent.getStringExtra("courts"));
        date.setText(intent.getStringExtra("date"));
        time.setText(intent.getStringExtra("time"));


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Payment_Page.this, Dashboard.class);
                Toast.makeText(Payment_Page.this, "Your reservation is being processed. Please wait a moment.", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

    }
}